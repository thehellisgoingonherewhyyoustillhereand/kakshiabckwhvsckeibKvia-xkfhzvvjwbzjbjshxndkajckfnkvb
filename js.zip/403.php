<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Challenge</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="https://cdn.jsdelivr.net/npm/notyf@3.1.0/notyf.min.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/notyf@3.1.0/notyf.min.css" rel="stylesheet">
    <style>
        body {
            background: #007bff; 
            background-image: radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px), radial-gradient(circle, rgba(255, 255, 255, 0.1) 1px, transparent 1px);
            background-size: 20px 20px;
            font-family: 'Roboto', sans-serif;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            padding: 40px;
            border-radius: 10px;
            background-color: rgba(0, 0, 0, 0.5);
            width: 100%;
            max-width: 500px;
            transition: background-color 0.3s ease;
        }
        h1 {
            margin-bottom: 20px;
            font-size: 36px;
        }
        .g-recaptcha {
            margin-bottom: 20px;
            display: inline-block;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 18px;
            font-family: 'Roboto', sans-serif;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
            transform: scale(1.05);
        }
        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: lightgray;
        }
        .error-container {
            background-color: #ff4d4d !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Zxeno-Firewall</h1>
        <p>You have been blocked temporarily, after unblocked you will need to solve a challenge.</p>
        <div class="footer">
            Protected by Zxeno-Firewall V4.6.1 Challenge-Id: Hidden
        </div>
    </div>
</body>
</html>