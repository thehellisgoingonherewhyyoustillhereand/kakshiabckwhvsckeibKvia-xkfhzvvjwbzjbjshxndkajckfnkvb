<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf/notyf.min.css">
    <script src="https://cdn.jsdelivr.net/npm/notyf/notyf.min.js"></script>
    <link rel="stylesheet" href="https://rbxruby.top/css/main.css">
</head>
<body>
    <div class="container">
        <div class="logo">404!</div>
        <p class="description">
            There isn't a page with this file or directory that is able to handle your request!
        </p>
        <div class="footer">
            <p>Want to explore more? <a href="">Join our Discord</a></p>
        </div>
    </div>
</body>
</html>